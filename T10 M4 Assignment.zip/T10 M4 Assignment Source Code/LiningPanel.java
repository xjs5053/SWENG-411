package LineDrawing;

import java.awt.Color;
import java.awt.Graphics;
import java.util.Random;

public class LiningPanel extends javax.swing.JPanel {

    private Random rand = new Random();

    public LiningPanel() { }

    @Override
    public void paintComponent(Graphics g)
    {
        super.paintComponent(g);
        int w = getWidth();
        int h = getHeight();

        int lines = 15;  // number of increments

        for (int i = 0; i <= lines; i++) {
            int wStep = (int)((i / (double)lines) * w);
            int hStep = (int)((i / (double)lines) * h);

            
            g.setColor(new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256))); // Random color
            g.drawLine(0, hStep, wStep, h); // Bottom-left (left -> bottom)

            g.setColor(new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256)));
            g.drawLine(w, hStep, wStep, 0); // Top-right (right -> top)

            g.setColor(new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256)));
            g.drawLine(wStep, 0, 0, h - hStep); // Top-left (top -> left)

            g.setColor(new Color(rand.nextInt(256), rand.nextInt(256), rand.nextInt(256)));
            g.drawLine(wStep, h, w, h - hStep); // Bottom-right (bottom -> right)
        }
    }
}



