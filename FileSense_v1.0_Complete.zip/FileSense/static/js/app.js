// FileSense JavaScript

// Update status on page load
window.addEventListener('DOMContentLoaded', function() {
    updateStatus();
    loadTags();
    loadSettings();
    
    // Update status every 2 seconds
    setInterval(updateStatus, 2000);
    
    // Enter key for search
    document.getElementById('search-input').addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchFiles();
        }
    });
});

// Update system status
async function updateStatus() {
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        // Update Ollama status
        const statusDot = document.querySelector('#ollama-status .status-dot');
        const statusText = document.querySelector('#ollama-status .status-text');
        
        if (data.ollama.running) {
            statusDot.classList.add('active');
            statusText.textContent = 'Ollama Running';
        } else if (data.ollama.installed) {
            statusDot.classList.remove('active');
            statusText.textContent = 'Ollama Installed (Not Running)';
        } else {
            statusDot.classList.remove('active');
            statusText.textContent = 'Ollama Not Installed';
        }
        
        // Update file count
        document.getElementById('file-count').textContent = `${data.stats.files} files indexed`;
        document.getElementById('stat-files').textContent = data.stats.files;
        document.getElementById('stat-tags').textContent = data.stats.tags;
        
        // Update Ollama detail status
        document.getElementById('ollama-detail-status').textContent = 
            data.ollama.running ? '✅ Running' : 
            data.ollama.installed ? '⚠️ Installed but not running' : 
            '❌ Not installed';
        
        document.getElementById('ollama-models').textContent = 
            data.ollama.models.length > 0 ? data.ollama.models.join(', ') : 'No models installed';
        
        document.getElementById('stat-ollama').textContent = 
            data.ollama.running ? 'Running' : 'Not Running';
        
        // Update indexing progress
        if (data.indexing.active) {
            const progress = document.getElementById('indexing-progress');
            progress.style.display = 'block';
            
            const percent = (data.indexing.progress / data.indexing.total) * 100;
            document.getElementById('progress-fill').style.width = percent + '%';
            document.getElementById('progress-text').textContent = 
                `Indexing... ${Math.round(percent)}%`;
            document.getElementById('progress-count').textContent = 
                `${data.indexing.progress} / ${data.indexing.total}`;
            document.getElementById('current-file').textContent = data.indexing.current_file;
        } else if (document.getElementById('progress-text').textContent !== 'Complete!') {
            // Show complete if was indexing
            if (document.getElementById('indexing-progress').style.display === 'block') {
                document.getElementById('progress-text').textContent = 'Complete!';
                document.getElementById('progress-fill').style.width = '100%';
            }
        }
        
    } catch (error) {
        console.error('Error updating status:', error);
    }
}

// Search files
async function searchFiles() {
    const query = document.getElementById('search-input').value.trim();
    const resultsDiv = document.getElementById('search-results');
    
    if (!query) {
        resultsDiv.innerHTML = '<p style="color: #999;">Enter a search query</p>';
        return;
    }
    
    resultsDiv.innerHTML = '<p>Searching...</p>';
    
    try {
        const response = await fetch('/api/search', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ query: query })
        });
        
        const data = await response.json();
        
        if (data.results.length === 0) {
            resultsDiv.innerHTML = '<p style="color: #999;">No results found</p>';
            return;
        }
        
        let html = `<h3>Found ${data.results.length} results:</h3>`;
        
        data.results.forEach(file => {
            const tags = file.tags ? file.tags.split(',').map(t => 
                `<span class="tag">${t}</span>`).join('') : '';
            
            html += `
                <div class="result-card">
                    <div class="result-title">📄 ${file.filename}</div>
                    <div class="result-path">${file.path}</div>
                    ${file.summary ? `<div class="result-summary">${file.summary}</div>` : ''}
                    ${tags ? `<div class="result-tags">${tags}</div>` : ''}
                    <div style="margin-top: 12px; font-size: 12px; color: #999;">
                        ${formatBytes(file.size)} • Modified: ${formatDate(file.modified_date)}
                    </div>
                </div>
            `;
        });
        
        resultsDiv.innerHTML = html;
        
    } catch (error) {
        resultsDiv.innerHTML = '<p style="color: #C41E3A;">Error searching files</p>';
        console.error('Search error:', error);
    }
}

// Start folder scan
async function startScan() {
    const folder = document.getElementById('folder-path').value.trim();
    
    if (!folder) {
        alert('Please enter a folder path');
        return;
    }
    
    try {
        const response = await fetch('/api/scan', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ folder: folder })
        });
        
        const data = await response.json();
        
        if (data.status === 'started') {
            document.getElementById('indexing-progress').style.display = 'block';
            document.getElementById('progress-text').textContent = 'Starting scan...';
        } else {
            alert('Error starting scan: ' + (data.error || 'Unknown error'));
        }
        
    } catch (error) {
        alert('Error starting scan');
        console.error('Scan error:', error);
    }
}

// Quick scan common folders
function quickScan(folderName) {
    const userProfile = '~'; // Will be expanded by backend
    const paths = {
        'Documents': `${userProfile}\\Documents`,
        'Downloads': `${userProfile}\\Downloads`,
        'Desktop': `${userProfile}\\Desktop`,
        'Pictures': `${userProfile}\\Pictures`
    };
    
    // For Windows, try common paths
    if (navigator.platform.includes('Win')) {
        document.getElementById('folder-path').value = 
            `C:\\Users\\${navigator.userAgent.split(' ')[0]}\\${folderName}`;
    }
    
    startScan();
}

// Download Ollama
function downloadOllama() {
    window.open('https://ollama.com/download', '_blank');
}

// Pull Ollama model
async function pullModel(modelName) {
    const button = event.target;
    button.disabled = true;
    button.textContent = 'Pulling...';
    
    try {
        const response = await fetch('/api/ollama/pull', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ model: modelName })
        });
        
        const data = await response.json();
        
        if (data.success) {
            button.textContent = '✓ Started';
            alert(`Started pulling ${modelName}. This may take several minutes. Check your terminal for progress.`);
        } else {
            button.textContent = 'Failed';
            alert('Failed to start model pull. Make sure Ollama is running.');
        }
        
    } catch (error) {
        button.textContent = 'Error';
        alert('Error pulling model');
        console.error('Pull error:', error);
    } finally {
        setTimeout(() => {
            button.disabled = false;
            button.textContent = 'Pull Model';
        }, 3000);
    }
}

// Test Ollama
async function testOllama() {
    const resultDiv = document.getElementById('test-result');
    resultDiv.textContent = 'Testing connection...';
    resultDiv.className = '';
    resultDiv.style.display = 'block';
    
    try {
        const response = await fetch('/api/status');
        const data = await response.json();
        
        if (data.ollama.running) {
            resultDiv.textContent = '✅ Ollama is running! Available models: ' + 
                (data.ollama.models.join(', ') || 'None');
            resultDiv.className = 'success';
        } else if (data.ollama.installed) {
            resultDiv.textContent = '⚠️ Ollama is installed but not running. Please start Ollama first.';
            resultDiv.className = 'error';
        } else {
            resultDiv.textContent = '❌ Ollama is not installed. Please download and install it first.';
            resultDiv.className = 'error';
        }
        
    } catch (error) {
        resultDiv.textContent = '❌ Error connecting to Ollama';
        resultDiv.className = 'error';
    }
}

// Load tags
async function loadTags() {
    try {
        const response = await fetch('/api/tags');
        const tags = await response.json();
        
        const container = document.getElementById('tags-container');
        
        if (tags.length === 0) {
            container.innerHTML = '<p style="color: #999;">No tags yet. Index some files first!</p>';
            return;
        }
        
        container.innerHTML = tags.slice(0, 20).map(tag => 
            `<span class="tag-item" onclick="searchByTag('${tag.tag_name}')">
                ${tag.tag_name} (${tag.usage_count})
            </span>`
        ).join('');
        
    } catch (error) {
        console.error('Error loading tags:', error);
    }
}

// Search by tag
function searchByTag(tagName) {
    document.getElementById('search-input').value = tagName;
    showTab('dashboard');
    searchFiles();
}

// Load settings
async function loadSettings() {
    try {
        const response = await fetch('/api/settings');
        const settings = await response.json();
        
        document.getElementById('auto-tag').checked = settings.auto_tag === 'true';
        document.getElementById('auto-summarize').checked = settings.auto_summarize === 'true';
        document.getElementById('ollama-model').value = settings.ollama_model || 'llama3.2:3b';
        
    } catch (error) {
        console.error('Error loading settings:', error);
    }
}

// Save settings
async function saveSettings() {
    const settings = {
        auto_tag: document.getElementById('auto-tag').checked ? 'true' : 'false',
        auto_summarize: document.getElementById('auto-summarize').checked ? 'true' : 'false',
        ollama_model: document.getElementById('ollama-model').value
    };
    
    try {
        const response = await fetch('/api/settings', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(settings)
        });
        
        const data = await response.json();
        
        if (data.success) {
            alert('Settings saved!');
        }
        
    } catch (error) {
        alert('Error saving settings');
        console.error('Settings error:', error);
    }
}

// Show tab
function showTab(tabName) {
    // Hide all tabs
    document.querySelectorAll('.tab-content').forEach(tab => {
        tab.classList.remove('active');
    });
    
    // Remove active from all buttons
    document.querySelectorAll('.tab-btn').forEach(btn => {
        btn.classList.remove('active');
    });
    
    // Show selected tab
    document.getElementById('tab-' + tabName).classList.add('active');
    
    // Mark button as active
    event.target.classList.add('active');
}

// Utility functions
function formatBytes(bytes) {
    if (!bytes || bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + ' ' + sizes[i];
}

function formatDate(dateStr) {
    if (!dateStr) return 'Unknown';
    const date = new Date(dateStr);
    return date.toLocaleDateString() + ' ' + date.toLocaleTimeString();
}
